package com.viraplay.player

import android.content.Context
import com.viraplay.shared.AppConfig
import com.viraplay.shared.DeviceConfig
import com.viraplay.shared.Http
import com.viraplay.shared.XtreamAccountClient
import com.viraplay.shared.XtreamAccountInfo
import java.net.URLEncoder
import org.json.JSONObject

class ContentRepository(
    private val context: Context,
    private val db: CatalogDb
) {
    private val prefs = context.getSharedPreferences("viraplay_network", Context.MODE_PRIVATE)
    private val xtream = XtreamSync()
    private val m3u = M3uSync()

    fun registerIfNeeded(identity: DeviceIdentity, platform: String, force: Boolean = false) {
        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_register", 0L)
        if (!force && last > 0L && now - last < 24L * 60L * 60L * 1000L) return

        val body = JSONObject()
            .put("device_id", identity.deviceId)
            .put("device_secret", identity.deviceSecret)
            .put("pairing_code", identity.pairingCode)
            .put("platform", platform)

        Http.postJson("${AppConfig.SERVER_BASE_URL}/api/register", body)
        prefs.edit().putLong("last_register", now).apply()
    }

    fun config(identity: DeviceIdentity, force: Boolean = false): DeviceConfig {
        val now = System.currentTimeMillis()
        val cachedEnabled = prefs.getBoolean("config_enabled", false)
        val cachedUrl = prefs.getString("config_playlist_url", null)
        val cachedName = prefs.getString("config_playlist_name", null)
        val cachedAt = prefs.getLong("config_cached_at", 0L)

        // Depois de ativado, evita consultas desnecessárias ao nosso backend:
        // o aparelho usa a configuração local por até 6 horas.
        if (
            !force &&
            cachedEnabled &&
            !cachedUrl.isNullOrBlank() &&
            cachedAt > 0L &&
            now - cachedAt < 6L * 60L * 60L * 1000L
        ) {
            return DeviceConfig(true, cachedUrl, cachedName)
        }

        val id = URLEncoder.encode(identity.deviceId, "UTF-8")
        val secret = URLEncoder.encode(identity.deviceSecret, "UTF-8")
        return runCatching {
            Http.parseDeviceConfig(
                Http.getText(
                    "${AppConfig.SERVER_BASE_URL}/api/config?device_id=$id&secret=$secret",
                    maxChars = 250_000
                )
            )
        }.onSuccess { cfg ->
            prefs.edit()
                .putBoolean("config_enabled", cfg.enabled)
                .putString("config_playlist_url", cfg.playlistUrl)
                .putString("config_playlist_name", cfg.playlistName)
                .putLong("config_cached_at", now)
                .apply()
        }.getOrElse {
            if (cachedEnabled && !cachedUrl.isNullOrBlank()) {
                DeviceConfig(true, cachedUrl, cachedName)
            } else {
                throw it
            }
        }
    }


    fun accountInfo(playlistUrl: String): XtreamAccountInfo? =
        runCatching { XtreamAccountClient.fetchFromPlaylist(playlistUrl) }.getOrNull()

    fun syncCatalog(
        playlistUrl: String,
        onProgress: (String) -> Unit = {}
    ): SyncResult {
        val credentials = SourceResolver.xtreamFromPlaylist(playlistUrl)
        if (credentials != null) {
            val xtreamResult = runCatching {
                xtream.sync(playlistUrl, db) { section, count ->
                    onProgress("$section: $count")
                }
            }
            if (xtreamResult.isSuccess) return xtreamResult.getOrThrow()
        }

        return m3u.sync(playlistUrl, db) { count ->
            onProgress("Organizando $count itens")
        }
    }

    fun episodes(parent: CatalogItem, force: Boolean = false): List<CatalogItem> {
        val sourceUrl = db.getMeta("playlist_url").orEmpty()
        return if (!parent.seriesId.isNullOrBlank() && SourceResolver.xtreamFromPlaylist(sourceUrl) != null) {
            xtream.loadEpisodes(sourceUrl, parent, db, force)
        } else {
            db.episodes(parent)
        }
    }

    fun epg(item: CatalogItem): List<EpgProgram> {
        val sourceUrl = db.getMeta("playlist_url").orEmpty()
        if (sourceUrl.isBlank()) return emptyList()

        val candidateIds = buildList {
            item.sourceId?.takeIf { it.isNotBlank() }?.let(::add)
            db.liveVariants(item)
                .mapNotNull { it.sourceId?.takeIf(String::isNotBlank) }
                .forEach { if (it !in this) add(it) }
        }

        for (streamId in candidateIds) {
            val programs = xtream.shortEpg(sourceUrl, streamId)
            if (programs.isNotEmpty()) return programs
        }

        return emptyList()
    }
}
