package com.viraplay.player

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.viraplay.shared.SupportConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private fun createSupportQrBitmap(content: String, size: Int = 360): Bitmap? = runCatching {
    val matrix = MultiFormatWriter().encode(
        content,
        BarcodeFormat.QR_CODE,
        size,
        size,
        mapOf(EncodeHintType.MARGIN to 1)
    )
    Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
        for (y in 0 until size) {
            for (x in 0 until size) {
                setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
    }
}.getOrNull()

@Composable
fun ActivationScreen(
    code: String,
    status: String,
    loading: Boolean,
    onRefresh: () -> Unit,
    onSupport: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(VpBg, VpPanel.copy(alpha = 0.78f), VpBg))
        ).padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandWordmark(large = true)
            Spacer(Modifier.height(24.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = VpPanel),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth()
            ) {
                Column(Modifier.padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Ative seu dispositivo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Envie este código ao suporte ViraPlay.", color = VpMuted, fontSize = 14.sp)
                    Spacer(Modifier.height(20.dp))
                    Surface(color = VpPanelAlt, shape = RoundedCornerShape(18.dp)) {
                        Text(
                            code,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 38.sp,
                            letterSpacing = 4.sp,
                            modifier = Modifier.padding(horizontal = 30.dp, vertical = 18.dp)
                        )
                    }
                    Spacer(Modifier.height(18.dp))
                    if (loading) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = VpCyan)
                        Spacer(Modifier.height(12.dp))
                    }
                    Text(status, color = if (status.startsWith("Falha")) VpDanger else VpMuted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onRefresh, enabled = !loading, modifier = Modifier.weight(1f)) {
                            Text(if (loading) "Carregando..." else "Atualizar")
                        }
                        OutlinedButton(onClick = onSupport, modifier = Modifier.weight(1f)) { Text("Suporte") }
                    }
                }
            }
        }
    }
}

@Composable
fun BlockedScreen(code: String, onSupport: () -> Unit, onRefresh: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(VpBg).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandWordmark(large = true)
        Spacer(Modifier.height(20.dp))
        Text("Acesso temporariamente bloqueado", color = VpDanger, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Spacer(Modifier.height(8.dp))
        Text("Código do aparelho: $code", color = VpMuted)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onSupport) { Text("Falar com suporte") }
            OutlinedButton(onClick = onRefresh) { Text("Tentar novamente") }
        }
    }
}

@Composable
fun SupportScreen(code: String, isTv: Boolean, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val qrBitmap = remember(code) { createSupportQrBitmap(SupportConfig.whatsappUrl(code)) }

    Surface(color = VpBg, modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.radialGradient(listOf(Color(0xFF0B2B4B), VpBg)))
                .padding(if (isTv) 38.dp else 22.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                BrandWordmark(large = true)
                Spacer(Modifier.height(18.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF071A34)),
                    border = BorderStroke(1.dp, VpCyan.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(26.dp),
                    modifier = Modifier.widthIn(max = if (isTv) 820.dp else 620.dp).fillMaxWidth()
                ) {
                    if (isTv) {
                        Row(
                            Modifier.fillMaxWidth().padding(24.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(26.dp)
                        ) {
                            qrBitmap?.let { bmp ->
                                Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = "QR Code do suporte",
                                        modifier = Modifier.size(210.dp).padding(10.dp)
                                    )
                                }
                            }
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                                Text("Suporte ViraPlay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 30.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("Aponte a câmera do celular para o QR Code", color = VpCyan, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(14.dp))
                                Text("WhatsApp", color = VpMuted, fontSize = 12.sp)
                                Text(SupportConfig.WHATSAPP_DISPLAY, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Text("Código do aparelho", color = VpMuted, fontSize = 12.sp)
                                Surface(color = VpPanelAlt, shape = RoundedCornerShape(12.dp)) {
                                    Text(code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = 2.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp))
                                }
                                Spacer(Modifier.height(18.dp))
                                OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
                            }
                        }
                    } else {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Suporte ViraPlay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                            Spacer(Modifier.height(12.dp))
                            qrBitmap?.let { bmp ->
                                Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) {
                                    Image(bitmap = bmp.asImageBitmap(), contentDescription = "QR Code do suporte", modifier = Modifier.size(190.dp).padding(10.dp))
                                }
                                Spacer(Modifier.height(12.dp))
                            }
                            Text(SupportConfig.WHATSAPP_DISPLAY, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("Código: $code", color = VpMuted)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { Support.openWhatsApp(context, code) }, modifier = Modifier.fillMaxWidth()) { Text("Abrir WhatsApp") }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    code: String,
    status: String,
    accessText: String?,
    isTv: Boolean,
    onBack: () -> Unit,
    onSupport: () -> Unit,
    onRefresh: () -> Unit,
    onParentalUnlocked: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val prefs = remember { PlaybackPreferences(context) }
    var groupChannels by remember { mutableStateOf(prefs.groupChannels) }
    var autoQuality by remember { mutableStateOf(prefs.autoQuality) }
    var manualQuality by remember { mutableStateOf(prefs.manualQuality) }
    var parentalEnabled by remember { mutableStateOf(prefs.parentalEnabled) }
    var pinDialog by remember { mutableStateOf(false) }
    var unlockDialog by remember { mutableStateOf(false) }
    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    val updateManager = remember { UpdateManager(context) }
    val updateScope = rememberCoroutineScope()
    var manualUpdate by remember { mutableStateOf<AppUpdateInfo?>(null) }
    var checkingUpdate by remember { mutableStateOf(false) }
    var installingUpdate by remember { mutableStateOf(false) }
    var updateStatus by remember {
        mutableStateOf("Toque em Verificar agora para procurar uma nova versão.")
    }
    var updateError by remember { mutableStateOf<String?>(null) }

    fun checkUpdateNow() {
        if (checkingUpdate || installingUpdate) return
        checkingUpdate = true
        updateError = null
        updateScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { updateManager.check() }
            }
            result.onSuccess { found ->
                manualUpdate = found
                updateStatus = if (found == null) {
                    "Você já está na versão mais recente."
                } else {
                    "Nova versão ${found.versionName} disponível."
                }
            }.onFailure { e ->
                updateError = (e.message ?: "Não foi possível verificar atualizações.").take(120)
                updateStatus = "Falha ao verificar atualização."
            }
            checkingUpdate = false
        }
    }

    fun installManualUpdate(info: AppUpdateInfo) {
        if (installingUpdate) return
        installingUpdate = true
        updateError = null
        updateStatus = "Baixando atualização..."
        updateScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { updateManager.download(info) }
            }
            result.onSuccess { apk ->
                installingUpdate = false
                when (updateManager.launchInstaller(apk)) {
                    InstallLaunchResult.STARTED -> {
                        updateStatus = "Instalador aberto. Conclua a atualização do ViraPlay."
                    }
                    InstallLaunchResult.NEED_PERMISSION -> {
                        updateStatus = "Autorize a instalação de apps desta fonte e volte para tentar novamente."
                    }
                }
            }.onFailure { e ->
                installingUpdate = false
                updateError = (e.message ?: "Não foi possível baixar a atualização.").take(120)
                updateStatus = "Falha ao baixar atualização."
            }
        }
    }

    Surface(color = VpBg, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .padding(if (isTv) 36.dp else 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BrandWordmark()
                Spacer(Modifier.weight(1f))
                OutlinedButton(onClick = onBack) { Text("Voltar") }
            }

            Text("Configurações", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Text("Informações e preferências do seu ViraPlay", color = VpMuted, fontSize = 12.sp)

            SettingsCard("Status", status)
            SettingsCard("Código do aparelho", code)
            accessText?.let { SettingsCard("Vencimento", it) }
            SettingsCard("Versão", "ViraPlay ${BuildConfig.VERSION_NAME}")

            Card(
                colors = CardDefaults.cardColors(containerColor = VpPanel),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("Atualizações", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Versão instalada: ${BuildConfig.VERSION_NAME}",
                        color = VpMuted,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        updateStatus,
                        color = if (manualUpdate != null) VpCyan else VpMuted,
                        fontSize = 12.sp
                    )
                    updateError?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, color = VpDanger, fontSize = 11.sp)
                    }

                    Button(
                        onClick = { checkUpdateNow() },
                        enabled = !checkingUpdate && !installingUpdate,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) {
                        Text(if (checkingUpdate) "Verificando..." else "Verificar agora")
                    }

                    manualUpdate?.let { info ->
                        OutlinedButton(
                            onClick = { installManualUpdate(info) },
                            enabled = !installingUpdate && !checkingUpdate,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Text(if (installingUpdate) "Baixando..." else "Baixar e instalar ${info.versionName}")
                        }
                    }
                }
            }

            ToggleCard(
                title = "Agrupar canais",
                subtitle = "Junta SD, HD, FHD e 4K do mesmo canal em uma única opção.",
                checked = groupChannels,
                onChecked = {
                    groupChannels = it
                    prefs.groupChannels = it
                }
            )

            ToggleCard(
                title = "Qualidade automática",
                subtitle = "Ativada por padrão. O app prioriza a melhor qualidade e reduz se a conexão não acompanhar.",
                checked = autoQuality,
                onChecked = {
                    autoQuality = it
                    prefs.autoQuality = it
                }
            )

            if (!autoQuality) {
                Card(colors = CardDefaults.cardColors(containerColor = VpPanel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("Qualidade preferida", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("4K", "FHD", "HD", "SD").forEach { q ->
                                FilterChip(
                                    selected = manualQuality == q,
                                    onClick = {
                                        manualQuality = q
                                        prefs.manualQuality = q
                                    },
                                    label = { Text(q) }
                                )
                            }
                        }
                    }
                }
            }

            ToggleCard(
                title = "Controle parental",
                subtitle = "Protege categorias e canais adultos com um PIN de 4 números.",
                checked = parentalEnabled,
                onChecked = {
                    parentalEnabled = it
                    prefs.parentalEnabled = it
                }
            )

            OutlinedButton(onClick = {
                currentPin = ""
                newPin = ""
                pinError = null
                pinDialog = true
            }, modifier = Modifier.fillMaxWidth()) {
                Text(if (prefs.hasPin()) "Alterar PIN parental" else "Criar PIN parental")
            }

            if (parentalEnabled && prefs.hasPin()) {
                OutlinedButton(onClick = {
                    currentPin = ""
                    pinError = null
                    unlockDialog = true
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Desbloquear conteúdo adulto nesta sessão")
                }
            }

            Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Atualizar catálogo") }
            OutlinedButton(onClick = onSupport, modifier = Modifier.fillMaxWidth()) { Text("Suporte ViraPlay") }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (pinDialog) {
        val changing = prefs.hasPin()
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            title = { Text(if (changing) "Alterar PIN" else "Criar PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (changing) {
                        OutlinedTextField(
                            value = currentPin,
                            onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) currentPin = it },
                            label = { Text("PIN atual") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) newPin = it },
                        label = { Text("Novo PIN (4 números)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    pinError?.let { Text(it, color = VpDanger) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (changing && !prefs.verifyPin(currentPin)) {
                        pinError = "PIN atual incorreto."
                    } else if (!prefs.setPin(newPin)) {
                        pinError = "Digite exatamente 4 números."
                    } else {
                        onParentalUnlocked()
                        pinDialog = false
                    }
                }) { Text("Salvar PIN") }
            },
            dismissButton = { TextButton(onClick = { pinDialog = false }) { Text("Cancelar") } }
        )
    }
    if (unlockDialog) {
        AlertDialog(
            onDismissRequest = { unlockDialog = false },
            title = { Text("Desbloquear conteúdo adulto") },
            text = {
                Column {
                    Text("Digite seu PIN de 4 números. O desbloqueio vale até fechar o aplicativo.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = currentPin,
                        onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) currentPin = it },
                        label = { Text("PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    pinError?.let { Text(it, color = VpDanger) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (prefs.verifyPin(currentPin)) {
                        onParentalUnlocked()
                        unlockDialog = false
                    } else pinError = "PIN incorreto."
                }) { Text("Desbloquear") }
            },
            dismissButton = { TextButton(onClick = { unlockDialog = false }) { Text("Cancelar") } }
        )
    }

}

@Composable
private fun ToggleCard(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = VpPanel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = VpMuted, fontSize = 11.sp)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun SettingsCard(title: String, value: String) {
    var focused by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (focused) VpCyan.copy(alpha = 0.16f) else VpPanel
        ),
        border = BorderStroke(if (focused) 3.dp else 1.dp, if (focused) Color.White else VpBorder),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused }
            .focusable()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = if (focused) VpCyan else VpMuted, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}
