package com.viraplay.player

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.viraplay.shared.SupportConfig

@Composable
fun ActivationScreen(
    code: String,
    status: String,
    loading: Boolean,
    onRefresh: () -> Unit,
    onSupport: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(VpBg, VpPanel.copy(alpha = 0.78f), VpBg))
        ).padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandWordmark(large = true)
            Spacer(Modifier.height(24.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = VpPanel),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.widthIn(max = 560.dp).fillMaxWidth()
            ) {
                Column(Modifier.padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Ative seu dispositivo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Envie este código ao suporte ViraPlay.", color = VpMuted, fontSize = 14.sp)
                    Spacer(Modifier.height(20.dp))
                    Surface(color = VpPanelAlt, shape = RoundedCornerShape(18.dp)) {
                        Text(
                            code,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 38.sp,
                            letterSpacing = 4.sp,
                            modifier = Modifier.padding(horizontal = 30.dp, vertical = 18.dp)
                        )
                    }
                    Spacer(Modifier.height(18.dp))
                    if (loading) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = VpCyan)
                        Spacer(Modifier.height(12.dp))
                    }
                    Text(status, color = if (status.startsWith("Falha")) VpDanger else VpMuted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onRefresh, enabled = !loading, modifier = Modifier.weight(1f)) {
                            Text(if (loading) "Carregando..." else "Atualizar")
                        }
                        OutlinedButton(onClick = onSupport, modifier = Modifier.weight(1f)) { Text("Suporte") }
                    }
                }
            }
        }
    }
}

@Composable
fun BlockedScreen(code: String, onSupport: () -> Unit, onRefresh: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(VpBg).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandWordmark(large = true)
        Spacer(Modifier.height(20.dp))
        Text("Acesso temporariamente bloqueado", color = VpDanger, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Spacer(Modifier.height(8.dp))
        Text("Código do aparelho: $code", color = VpMuted)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onSupport) { Text("Falar com suporte") }
            OutlinedButton(onClick = onRefresh) { Text("Tentar novamente") }
        }
    }
}

@Composable
fun SupportScreen(code: String, isTv: Boolean, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    Surface(color = VpBg, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(if (isTv) 42.dp else 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BrandWordmark(large = true)
            Spacer(Modifier.height(22.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = VpPanel),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.widthIn(max = 620.dp).fillMaxWidth()
            ) {
                Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Suporte ViraPlay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("WhatsApp", color = VpCyan, fontWeight = FontWeight.SemiBold)
                    Text(SupportConfig.WHATSAPP_DISPLAY, color = Color.White, fontSize = 22.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Código deste aparelho: $code", color = VpMuted)
                    Spacer(Modifier.height(18.dp))
                    if (isTv) {
                        Text("Abra o WhatsApp no celular e envie seu código para o número acima.", color = VpMuted, fontSize = 14.sp)
                    } else {
                        Button(onClick = { Support.openWhatsApp(context, code) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Abrir WhatsApp")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    code: String,
    status: String,
    accessText: String?,
    isTv: Boolean,
    onBack: () -> Unit,
    onSupport: () -> Unit,
    onRefresh: () -> Unit,
    onParentalUnlocked: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val prefs = remember { PlaybackPreferences(context) }
    var groupChannels by remember { mutableStateOf(prefs.groupChannels) }
    var autoQuality by remember { mutableStateOf(prefs.autoQuality) }
    var manualQuality by remember { mutableStateOf(prefs.manualQuality) }
    var parentalEnabled by remember { mutableStateOf(prefs.parentalEnabled) }
    var pinDialog by remember { mutableStateOf(false) }
    var unlockDialog by remember { mutableStateOf(false) }
    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    Surface(color = VpBg, modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .padding(if (isTv) 36.dp else 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BrandWordmark()
                Spacer(Modifier.weight(1f))
                OutlinedButton(onClick = onBack) { Text("Voltar") }
            }

            Text("Configurações", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Text("Informações e preferências do seu ViraPlay", color = VpMuted, fontSize = 12.sp)

            SettingsCard("Status", status)
            SettingsCard("Código do aparelho", code)
            accessText?.let { SettingsCard("Vencimento", it) }
            SettingsCard("Versão", "ViraPlay 3.2.0 Beta")

            ToggleCard(
                title = "Agrupar canais",
                subtitle = "Junta SD, HD, FHD e 4K do mesmo canal em uma única opção.",
                checked = groupChannels,
                onChecked = {
                    groupChannels = it
                    prefs.groupChannels = it
                }
            )

            ToggleCard(
                title = "Qualidade automática",
                subtitle = "Ativada por padrão. O app prioriza a melhor qualidade e reduz se a conexão não acompanhar.",
                checked = autoQuality,
                onChecked = {
                    autoQuality = it
                    prefs.autoQuality = it
                }
            )

            if (!autoQuality) {
                Card(colors = CardDefaults.cardColors(containerColor = VpPanel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("Qualidade preferida", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("4K", "FHD", "HD", "SD").forEach { q ->
                                FilterChip(
                                    selected = manualQuality == q,
                                    onClick = {
                                        manualQuality = q
                                        prefs.manualQuality = q
                                    },
                                    label = { Text(q) }
                                )
                            }
                        }
                    }
                }
            }

            ToggleCard(
                title = "Controle parental",
                subtitle = "Protege categorias e canais adultos com um PIN de 4 números.",
                checked = parentalEnabled,
                onChecked = {
                    parentalEnabled = it
                    prefs.parentalEnabled = it
                }
            )

            OutlinedButton(onClick = {
                currentPin = ""
                newPin = ""
                pinError = null
                pinDialog = true
            }, modifier = Modifier.fillMaxWidth()) {
                Text(if (prefs.hasPin()) "Alterar PIN parental" else "Criar PIN parental")
            }

            if (parentalEnabled && prefs.hasPin()) {
                OutlinedButton(onClick = {
                    currentPin = ""
                    pinError = null
                    unlockDialog = true
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Desbloquear conteúdo adulto nesta sessão")
                }
            }

            Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Atualizar catálogo") }
            OutlinedButton(onClick = onSupport, modifier = Modifier.fillMaxWidth()) { Text("Suporte ViraPlay") }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (pinDialog) {
        val changing = prefs.hasPin()
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            title = { Text(if (changing) "Alterar PIN" else "Criar PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (changing) {
                        OutlinedTextField(
                            value = currentPin,
                            onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) currentPin = it },
                            label = { Text("PIN atual") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) newPin = it },
                        label = { Text("Novo PIN (4 números)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    pinError?.let { Text(it, color = VpDanger) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (changing && !prefs.verifyPin(currentPin)) {
                        pinError = "PIN atual incorreto."
                    } else if (!prefs.setPin(newPin)) {
                        pinError = "Digite exatamente 4 números."
                    } else {
                        onParentalUnlocked()
                        pinDialog = false
                    }
                }) { Text("Salvar PIN") }
            },
            dismissButton = { TextButton(onClick = { pinDialog = false }) { Text("Cancelar") } }
        )
    }
    if (unlockDialog) {
        AlertDialog(
            onDismissRequest = { unlockDialog = false },
            title = { Text("Desbloquear conteúdo adulto") },
            text = {
                Column {
                    Text("Digite seu PIN de 4 números. O desbloqueio vale até fechar o aplicativo.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = currentPin,
                        onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) currentPin = it },
                        label = { Text("PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    pinError?.let { Text(it, color = VpDanger) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (prefs.verifyPin(currentPin)) {
                        onParentalUnlocked()
                        unlockDialog = false
                    } else pinError = "PIN incorreto."
                }) { Text("Desbloquear") }
            },
            dismissButton = { TextButton(onClick = { unlockDialog = false }) { Text("Cancelar") } }
        )
    }

}

@Composable
private fun ToggleCard(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = VpPanel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = VpMuted, fontSize = 11.sp)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun SettingsCard(title: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = VpPanel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = VpMuted, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}
